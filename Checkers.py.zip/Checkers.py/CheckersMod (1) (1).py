# Code designed and written by: Muhammad Ahmed Saqib
# Andrew ID: msaqib
# File Created: November 11, 11:00am
# Modification History:
# Start End
# 11/11 11:00 am 12/11 12:30 am
# 12/11 8:45 am 12/11 1:10 pm
# 17/11 1:10 pm 17/11 5:00 pm
# 17/11 7:45 pm 17/11 9:45 pm
# 18/11 8:10 pm 18/11 9:15 pm
# 20/11 4:00pm  20/11 8:00 pm
# 22/11 10:00am 22/11 8:00 pm
# 24/11 1:00 pm 24/11 6:00 pm
# 25/11 12:00 pm 25/11 7:15 pm
# 26/11 4:00 pm  26/11 10:00 pm



import pygame
from Tkinter import *
from PIL import ImageTk, Image

#This is the function which displays and makes changes to the user vs user game based on mouse positions, it uses 2 major functions, highlight moves and evaluate moves
def mainFunction1():
    pygame.quit()
    white =(255,255,255)
    black = (0,0,0)
    green = (0,0,0)
    red = (255,0,0)
    blue = (0,0,255)
    gold = (255,215,0)
    gameScreen = pygame.display.set_mode((800, 800))
    pygame.display.set_caption("Checkers")
    gameEnd = False
    clock = pygame.time.Clock()
    drawBoard(gameScreen)
    pieceList = drawPieces(gameScreen)
    locationList = boxLocations(gameScreen)
    loc = False
    global Turn
    global greenList
    global redList
    Turn = True
    variable = False
    BN = -1
    global Kbool
    Kbool = False
    #game loop
    while gameEnd == False:
        pygame.display.flip()
        #event loop
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                        gameEnd = True
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mPosition = pygame.mouse.get_pos()
                    loc = False
                    i = 1
                    winner = winCheck(pieceList,locationList) #checks to see if game won
                    if winner == "Red Wins":
                        wonGameRed() #displays a window
                    elif winner == "Green Wins":
                        wonGameBlack() #displays a window
                    pieceList = makeKingPiece(gameScreen,pieceList,locationList)
                    if variable == False:
                       variable = evaluateMove(gameScreen,locationList,pieceList,variable,mPosition,BN)
                    if variable == "H":
                        #this loop removes all the highlighted(blue squares) after a move has been made
                        while i < len(locationList):
                            if gameScreen.get_at((locationList[i][0]+46,locationList[i][1]))  == (0,0,255,255):
                                if gameScreen.get_at((locationList[i-2][0]+46,locationList[i-2][1])) == (255,255,255,255) and locationList[i-1] % 8 != 0 :
                                   pygame.draw.rect(gameScreen,green,pygame.Rect((locationList[i][0] - 50),(locationList[i][1] - 50),100,100))
                                else:
                                   pygame.draw.rect(gameScreen,white,pygame.Rect((locationList[i][0] - 50),(locationList[i][1] - 50),100,100))
                            i += 2
                        #calls highlight moves function and stores the boxnumber clicked on
                        BN = highlightMoves(gameScreen,pieceList,locationList,loc,mPosition)
                        variable = False
                    elif variable == "N" or variable == "K" or variable == "M":
                        variable = False
        clock.tick(50)
        # if key up is pressed, menu is opened
        up = pygame.key.get_pressed()[pygame.K_UP]
        if up == 1:
            gameEnd == True
            menufunc()
        #if key down is pressed, game is restarted
        down = pygame.key.get_pressed()[pygame.K_DOWN]
        if down == 1:
            gameEnd == True
            mainFunction1()                
    pygame.quit()

#draws board using rectangles
def drawBoard(gameScreen):
    white =(255,255,255)
    black = (0,0,0)
    green = (0,0,0)
    red = (255,0,0)
    x = 0
    y = 0
    for e in range(8):
        for i in range(8):
          if e%2 == 0:
              if i%2 == 0:
                pygame.draw.rect(gameScreen,green,pygame.Rect(x,y,100,100))
              else:
                pygame.draw.rect(gameScreen,white,pygame.Rect(x,y,100,100))
          else:
              if i%2 == 0:
                pygame.draw.rect(gameScreen,white,pygame.Rect(x,y,100,100))
              else:
                pygame.draw.rect(gameScreen,green,pygame.Rect(x,y,100,100))
          x += 100
        y += 100
        x = 0

#draws circles as pieces
def drawPieces(gameScreen):
    white =(255,255,255)
    black = (0,0,0)
    green = (0,0,0)
    red = (255,0,0)
    x = 50
    y = 50
    a = 150                
    redPiece = -1
    greenPiece = 11
    pieceList = []
    for e in range(8):
        for i in range(4):
            if e == 0 or e == 1 or e == 2:
                 if e%2 == 0:
                        pygame.draw.circle(gameScreen,red,(a,y),40)
                        redPiece += 1
                        pieceList = pieceList + [redPiece]
                        pieceList = pieceList + [(a,y)]
                        a += 200
                 else:
                        pygame.draw.circle(gameScreen,red,(x,y),40)
                        redPiece += 1
                        pieceList = pieceList + [redPiece]
                        pieceList = pieceList + [(x,y)]
                        x += 200
            if e == 5 or e == 6 or e == 7:
                if e%2 == 0:
                        pygame.draw.circle(gameScreen,green,(a,y),40)
                        greenPiece += 1
                        pieceList = pieceList + [greenPiece]
                        pieceList = pieceList + [(a,y)]
                        a += 200
                else:
                        pygame.draw.circle(gameScreen,green,(x,y),40)
                        greenPiece += 1
                        pieceList = pieceList + [greenPiece]
                        pieceList = pieceList + [(x,y)]
                        x += 200         
        a = 150        
        x = 50
        y += 100
    return pieceList
#stores the location of each square where the center of the square are its coordinates
def boxLocations(gameScreen):
    locationList = []
    x = 50
    y = 50
    Box = 0
    global greenList
    global redList
    greenList = [0] * 8
    redList= [0] * 8
    for e in range(8):
        for i in range(8):
            if e == 0:
                greenList[i] = (x,y)
            if e == 7:
                redList[i] = (x,y) 
            locationList = locationList + [Box]
            locationList = locationList + [(x,y)]
            x += 100
            Box += 1
        y += 100
        x=50
    return locationList


#not for moves where the tile is occupied
def highlightMoves(gameScreen,pieceList,locationList,loc,mPosition):
     global Turn
     global greenList
     global redList
     white =(255,255,255)
     black = (0,0,0)
     green = (0,0,0)
     red = (255,0,0)
     blue = (0,0,255)
     gold = (255,215,0)
     Location1 = ' '
     Location2 = ' '
     Location3 =' '
     Location4 = ' '
     Coords = (' ', ' ')
     boolK = False
     cMove = False
     Bool3 = False
     i = 1
     global List
     List = []
     global boxNumber
     boxNumber = []
     if Turn == True:
         for x in range(len(pieceList[:24])):
             if x%2 == 1:
                 #works for king pieces as king piece number is -1
                 if pieceList[x-1] == -1:
                    if pieceList[x][0] != 50 and pieceList[x][0] != 750:
                      # in the following code, it is checked to see if a red piece is in position to kill, if it is it changes the value of a boolean. it checks
                      #to see if a kill can be made based on each piece's next possible moves. This is done by adding a 100 or subtracting a 100 (or 200 if a piece
                      # occupies those position) from the x and y coordinates of the piece.
                      coordList = [((pieceList[x][0]-100),(pieceList[x][1]-100)),((pieceList[x][0]-100),(pieceList[x][1]+100)),((pieceList[x][0]+100),(pieceList[x][1]+100)),((pieceList[x][0]+100),(pieceList[x][1]-100))]
                      for i in range(len(coordList)):
                          if coordList[i][0] > 0 and coordList[i][0] < 800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                             if coordList[i] in pieceList:
                                 if coordList[i] in pieceList[24:]:
                                     if i == 0:
                                         if (coordList[i][0]-100) > 0 and (coordList[i][1]-100)>0:
                                             if ((coordList[i][0]-100),(coordList[i][1]-100)) not in pieceList:
                                               if coordList[i][0]-100 > 0 and coordList[i][1]-100 > 0:
                                                 cMove = True
                                                 cCoords = ((coordList[i][0]-100),(coordList[i][1]-100))
                                                 
                                     elif i == 1 and pieceList[x] not in redList:    
                                         if (coordList[i][0]-100) > 0 and (coordList[i][1]+100)>0:
                                             if ((coordList[i][0]-100),(coordList[i][1]+100)) not in pieceList:
                                               if coordList[i][0]-100 > 0 and coordList[i][1]+100 < 800:
                                                 cMove = True
                                                 cCoords = ((coordList[i][0]-100),(coordList[i][1]+100))
                                     elif i == 2 and pieceList[x] not in redList:  
                                         if (coordList[i][0]+100) > 0 and (coordList[i][1]+100)>0:
                                             if ((coordList[i][0]+100),(coordList[i][1]+100)) not in pieceList:
                                              if coordList[i][0]+100 < 800 and coordList[i][1]+100 < 800:
                                                 cMove = True
                                                 cCoords = ((coordList[i][0]+100),(coordList[i][1]+100))
                                     elif i == 3:
                                         if (coordList[i][0]+100) > 0 and (coordList[i][1]-100)>0:
                                             if ((coordList[i][0]+100),(coordList[i][1]-100)) not in pieceList:
                                                if coordList[i][0]+100 < 800 and coordList[i][1]-100 > 0:
                                                 cMove = True
                                                 cCoords = ((coordList[i][0]+100),(coordList[i][1]-100))
                                     prev = " "
                                     for i in locationList:
                                         if i == pieceList[x]:
                                             boxNumberC = prev
                                         prev = i
                    elif pieceList[x][0] == 50:
                           coordList = [((pieceList[x][0]+100),(pieceList[x][1]+100)),((pieceList[x][0]+100),(pieceList[x][1]-100))]
                           for i in range(len(coordList)):
                               if coordList[i][0] > 0 and coordList[i][0] < 800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                                 if coordList[i] in pieceList:
                                     if coordList[i] in pieceList[24:]:
                                         if i == 0:
                                             
                                             if (coordList[i][0]+100) > 0 and (coordList[i][1]+100)>0:
                                                 if ((coordList[i][0]+100),(coordList[i][1]+100)) not in pieceList:
                                                  if coordList[i][0]+100 < 800 and coordList[i][1]+100 < 800:
                                                     cMove = True
                                                     cCoords = ((coordList[i][0]+100),(coordList[i][1]+100))
                                         if i == 1:
                                             
                                             if (coordList[i][0]+100) > 0 and (coordList[i][1]-100)>0:
                                                 if ((coordList[i][0]+100),(coordList[i][1]-100)) not in pieceList:
                                                  if coordList[i][0]+100 <  800 and coordList[i][1]-100 > 0:
                                                     cMove = True
                                                     cCoords = ((coordList[i][0]+100),(coordList[i][1]-100))
                                         prev = " "
                                         for i in locationList:
                                             if i == pieceList[x]:
                                                 boxNumberC = prev
                                             prev = i
                    elif pieceList[x][0] == 750:
                           coordList = [((pieceList[x][0]-100),(pieceList[x][1]+100)),((pieceList[x][0]-100),(pieceList[x][1]-100))]
                           for i in range(len(coordList)):
                               if coordList[i][0] > 0 and coordList[i][0] < 800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                                 if coordList[i] in pieceList:
                                     if coordList[i] in pieceList[24:]:
                                         if i == 0:
                                             
                                             if (coordList[i][0]-100) > 0 and (coordList[i][1]+100)>0:
                                                 if ((coordList[i][0]-100),(coordList[i][1]+100)) not in pieceList:
                                                  if coordList[i][0]-100 > 0 and coordList[i][1]+100 < 800:
                                                     cMove = True
                                                     cCoords = ((coordList[i][0]-100),(coordList[i][1]+100))
                                         if i == 1:
                                             
                                             if (coordList[i][0]-100) > 0 and (coordList[i][1]-100)>0:
                                                 if ((coordList[i][0]-100),(coordList[i][1]-100)) not in pieceList:
                                                   if coordList[i][0]-100 > 0 and coordList[i][1]-100 > 0:
                                                     cMove = True
                                                     cCoords = ((coordList[i][0]-100),(coordList[i][1]-100))
                                         prev = " "
                                         for i in locationList:
                                             if i == pieceList[x]:
                                                 boxNumberC = prev
                                             prev = i
                 elif pieceList[x-1] > 0:
                      if pieceList[x][0] != 50 and pieceList[x][0] != 750:
                        coordList = [((pieceList[x][0]+100),(pieceList[x][1]+100)),((pieceList[x][0]-100),(pieceList[x][1]+100))]
                        for i in range(len(coordList)):
                          if coordList[i][0] > 0 and coordList[i][0] < 800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                             if coordList[i] in pieceList:
                                 if coordList[i] in pieceList[24:]:
                                   if coordList[i][0] != 50 and coordList[i][0]!=750:
                                     if i == 0:
                                         if (coordList[i][0]+100) > 0 and (coordList[i][1]+100)>0:
                                             if ((coordList[i][0]+100),(coordList[i][1]+100)) not in pieceList:
                                              if coordList[i][0]+100 < 800 and coordList[i][1]+100 < 800:
                                                 cMove = True
                                                 cCoords = ((coordList[i][0]+100),(coordList[i][1]+100))
                                                 List = List + [cCoords]
                                                
                                     if i == 1:
                                         if (coordList[i][0]-100) > 0 and (coordList[i][1]+100)>0:
                                             if ((coordList[i][0]-100),(coordList[i][1]+100)) not in pieceList:
                                               if coordList[i][0]-100 > 0 and coordList[i][1]+100 < 800:
                                                 cMove = True
                                                 cCoords = ((coordList[i][0]-100),(coordList[i][1]+100))
                                                 List = List + [cCoords]
                                     prev = " "
                                     for i in locationList:
                                         if i == pieceList[x]:
                                             boxNumber = boxNumber + [prev]  
                                         prev = i
                                     
                      elif pieceList[x][0] == 50:
                           coordList = [((pieceList[x][0]+100),(pieceList[x][1]+100))]
                           for i in range(len(coordList)):
                               if coordList[i][0] > 0 and coordList[i][0] < 800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                                 if coordList[i] in pieceList:
                                     if coordList[i] in pieceList[24:]:
                                          if i == 0:
                                             if (coordList[i][0]+100) > 0 and (coordList[i][1]+100)>0:
                                                 if ((coordList[i][0]+100),(coordList[i][1]+100)) not in pieceList:
                                                  if coordList[i][0]+100 < 800 and coordList[i][1]+100 < 800:
                                                     cMove = True
                                                     cCoords = ((coordList[i][0]+100),(coordList[i][1]+100))
                                                     List = List + [cCoords]
                                          prev = " "
                                          for i in locationList:
                                             if i == pieceList[x]:
                                                 boxNumber = boxNumber + [prev]  
                                             prev = i
                                         
                                     
                      elif pieceList[x][0] == 750:
                           coordList = [((pieceList[x][0]-100),(pieceList[x][1]+100))]
                           for i in range(len(coordList)):
                               if coordList[i][0] > 0 and coordList[i][0] < 800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                                 if coordList[i] in pieceList:
                                     if coordList[i] in pieceList[24:]:
                                          if i == 0:
                                             if (coordList[i][0]-100) > 0 and (coordList[i][1]+100)>0:
                                                 if ((coordList[i][0]-100),(coordList[i][1]+100)) not in pieceList:
                                                   if coordList[i][0]-100 > 0 and coordList[i][1]+100 < 800:
                                                     cMove = True
                                                     cCoords = ((coordList[i][0]-100),(coordList[i][1]+100))
                                                     List = List + [cCoords]
                                                     
                                          prev = " "
                                          for i in locationList:
                                             if i == pieceList[x]:
                                                 boxNumber = boxNumber + [prev]  
                                             prev = i
    #this is also part of the code above and has the same functionality but for the black pieces                                  
     elif Turn == False:
         
         for x in range(len(pieceList[24:])):
             if x%2 == 1:
                 if pieceList[x+23] == 30:
                    if pieceList[x+24][0] != 50 and pieceList[x+24][0] != 750:
                      coordList = [((pieceList[x+24][0]-100),(pieceList[x+24][1]-100)),((pieceList[x+24][0]-100),(pieceList[x+24][1]+100)),((pieceList[x+24][0]+100),(pieceList[x+24][1]+100)),((pieceList[x+24][0]+100),(pieceList[x+24][1]-100))]
                      for i in range(len(coordList)):
                          if coordList[i][0] > 0 and coordList[i][0] < 800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                             if coordList[i] in pieceList:
                                 if coordList[i] in pieceList[:24]:
                                     if i == 0:
                                         if (coordList[i][0]-100) > 0 and (coordList[i][1]-100)>0:
                                             if ((coordList[i][0]-100),(coordList[i][1]-100)) not in pieceList:
                                              if coordList[i][0]-100 > 0 and coordList[i][1]-100 > 0:
                                                 cMove = True
                                                 cCoords = ((coordList[i][0]-100),(coordList[i][1]-100))
                                     if i == 1:
                                         if (coordList[i][0]-100) > 0 and (coordList[i][1]+100)>0:
                                             if ((coordList[i][0]-100),(coordList[i][1]+100)) not in pieceList:
                                               if coordList[i][0]-100 > 0 and coordList[i][1]+100 < 800:
                                                 cMove = True
                                                 cCoords = ((coordList[i][0]-100),(coordList[i][1]+100))
                                     if i == 2:
                                         if (coordList[i][0]+100) > 0 and (coordList[i][1]+100)>0:
                                             if ((coordList[i][0]+100),(coordList[i][1]+100)) not in pieceList:
                                                if coordList[i][0]+100 < 800 and coordList[i][1]+100 < 800:
                                                 cMove = True
                                                 cCoords = ((coordList[i][0]+100),(coordList[i][1]+100))
                                     if i == 3:
                                         if (coordList[i][0]+100) > 0 and (coordList[i][1]-100)>0:
                                             if ((coordList[i][0]+100),(coordList[i][1]-100)) not in pieceList:
                                                if coordList[i][0]+100 < 800 and coordList[i][1]-100 > 0:
                                                 cMove = True
                                                 cCoords = ((coordList[i][0]+100),(coordList[i][1]-100))
                                     prev = " "
                                     for i in locationList:
                                         if i == pieceList[x+24]:
                                             boxNumberC = prev
                                         prev = i
                    elif pieceList[x+24][0] == 50:
                           coordList = [((pieceList[x+24][0]+100),(pieceList[x+24][1]+100)),((pieceList[x+24][0]+100),(pieceList[x+24][1]-100))]
                           for i in range(len(coordList)):
                               if coordList[i][0] > 0 and coordList[i][0] < 800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                                 if coordList[i] in pieceList:
                                     if coordList[i] in pieceList[:24]:
                                         if i == 0:
                                             if (coordList[i][0]+100) > 0 and (coordList[i][1]+100)>0:
                                                 if ((coordList[i][0]+100),(coordList[i][1]+100)) not in pieceList:
                                                    if coordList[i][0]+100 < 800 and coordList[i][1]+100 < 800:
                                                     cMove = True
                                                     cCoords = ((coordList[i][0]+100),(coordList[i][1]+100))
                                                     List
                                         if i == 1:
                                             if (coordList[i][0]+100) > 0 and (coordList[i][1]-100)>0:
                                                 if ((coordList[i][0]+100),(coordList[i][1]-100)) not in pieceList:
                                                   if coordList[i][0]+100 < 800 and coordList[i][1]-100 > 0:
                                                     cMove = True
                                                     cCoords = ((coordList[i][0]+100),(coordList[i][1]-100))
                                         prev = " "
                                         for i in locationList:
                                             if i == pieceList[x+24]:
                                                 boxNumberC = prev
                                             prev = i
                    elif pieceList[x+24][0] == 750:
                           coordList = [((pieceList[x+24][0]-100),(pieceList[x+24][1]+100)),((pieceList[x+24][0]-100),(pieceList[x+24][1]-100))]
                           for i in range(len(coordList)):
                               if coordList[i][0] > 0 and coordList[i][0] < 800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                                 if coordList[i] in pieceList:
                                     if coordList[i] in pieceList[:24]:
                                         if i == 0:
                                             if (coordList[i][0]-100) > 0 and (coordList[i][1]+100)>0:
                                                 if ((coordList[i][0]-100),(coordList[i][1]+100)) not in pieceList:
                                                   if coordList[i][0]-100 > 0 and coordList[i][1]+100 < 800:
                                                     cMove = True
                                                     cCoords = ((coordList[i][0]-100),(coordList[i][1]+100))
                                         if i == 1:
                                             if (coordList[i][0]-100) > 0 and (coordList[i][1]-100)>0:
                                                 if ((coordList[i][0]-100),(coordList[i][1]-100)) not in pieceList:
                                                    if coordList[i][0]-100 > 0 and coordList[i][1]-100 > 0:
                                                     cMove = True
                                                     cCoords = ((coordList[i][0]-100),(coordList[i][1]-100))
                                         prev = " "
                                         for i in locationList:
                                             if i == pieceList[x+24]:
                                                 boxNumberC = prev
                                             prev = i
                 elif pieceList[x+23] > 0:
                      if pieceList[x+24][0] != 50 and pieceList[x+24][0] != 750:
                        coordList = [((pieceList[x+24][0]-100),(pieceList[x+24][1]-100)),((pieceList[x+24][0]+100),(pieceList[x+24][1]-100))]
                        for i in range(len(coordList)):
                          if coordList[i][0] > 0 and coordList[i][0] < 800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                             if coordList[i] in pieceList:
                                 if coordList[i] in pieceList[:24]:
                                   if coordList[i][0] != 50 and coordList[i][0]!=750:
                                  
                                     if i == 0:
                                         if (coordList[i][0]-100) > 0 and (coordList[i][1]-100)>0:
                                             if ((coordList[i][0]-100),(coordList[i][1]-100)) not in pieceList:
                                              if coordList[i][0]-100 > 0 and coordList[i][1]-100 > 0:
                                                 cMove = True
                                                 cCoords = ((coordList[i][0]-100),(coordList[i][1]-100))
                                                 List = List + [cCoords]
                                                 
                                         
                                     elif i == 1:
                                         if (coordList[i][0]+100) > 0 and (coordList[i][1]-100)>0:
                                             if ((coordList[i][0]+100),(coordList[i][1]-100)) not in pieceList:
                                              if coordList[i][0]+100 < 800 and coordList[i][1]-100 > 0:
                                                 cMove = True
                                                 cCoords = ((coordList[i][0]+100),(coordList[i][1]-100))
                                                 List = List + [cCoords]
                                     prev = " "
                                     for i in locationList:
                                         if i == pieceList[x+24]:
                                             boxNumber = boxNumber + [prev]  
                                         prev = i
                                 #print boxNumber
                      elif pieceList[x+24][0] == 50:
                           coordList = [((pieceList[x+24][0]+100),(pieceList[x+24][1]-100))]
                           for i in range(len(coordList)):
                               if coordList[i][0] > 0 and coordList[i][0] < 800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                                 if coordList[i] in pieceList:
                                     if coordList[i] in pieceList[:24]:
                            
                                         if i == 0:
                                             if (coordList[i][0]+100) > 0 and (coordList[i][1]-100)>0:
                                                 if ((coordList[i][0]+100),(coordList[i][1]-100)) not in pieceList:
                                                    if coordList[i][0]+100 < 800 and coordList[i][1]-100 > 0:
                                                     cMove = True
                                                     cCoords = ((coordList[i][0]+100),(coordList[i][1]-100))
                                                     List = List + [cCoords]
                                         prev = " "
                                         for i in locationList:
                                             if i == pieceList[x+24]:
                                                 boxNumber = boxNumber + [prev]  
                                             prev = i
                                         
                      elif pieceList[x+24][0] == 750:
                           coordList = [((pieceList[x+24][0]-100),(pieceList[x+24][1]-100))]
                           for i in range(len(coordList)):
                               if coordList[i][0] > 0 and coordList[i][0] < 800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                                 if coordList[i] in pieceList:
                                     if coordList[i] in pieceList[:24]:
                                         if i == 0:
                                             if (coordList[i][0]-100) > 0 and (coordList[i][1]-100)>0:
                                                 if ((coordList[i][0]-100),(coordList[i][1]-100)) not in pieceList:
                                                  if coordList[i][0]-100 > 0 and coordList[i][1]-100 > 0:
                                                     cMove = True
                                                     cCoords = ((coordList[i][0]-100),(coordList[i][1]-100))
                                                     List = List + [cCoords]
                                         prev = " "
                                         for i in locationList:
                                             if i == pieceList[x+24]:
                                                 boxNumber = boxNumber + [prev]  
                                             prev = i
     i = 1
     # if cMove equals true then it means a red piece or a black piece is in a position to move so the code checks the mouse position to calculate the box the user clicked on
     # and if the box number matches the box (which has the piece which can kill), then it highlights the box where the piece can be moved to.
     if cMove == True:
         while i < len(locationList):
            if i%2 != 0:
                if mPosition[0] < (locationList[i][0] + 50) and mPosition[0] > (locationList[i][0] - 50) and mPosition[1] < (locationList[i][1] + 50) and abs(locationList[i][1] - mPosition[1]) < 50:
                    BN = locationList[i-1]
                    if List == []:
                        if BN == boxNumberC:
                                pygame.draw.rect(gameScreen,blue,pygame.Rect((cCoords[0]-50),(cCoords[1]-50),100,100))
                                
                    else:
                      for d in List:
                        for x in boxNumber:
                            if BN == x:
                                pygame.draw.rect(gameScreen,blue,pygame.Rect((d[0]-50),(d[1]-50),100,100))
                      List = []
                      boxNumber = []
                                
            i += 2
                        
     i = 1
     #if cMove is false, then killing is not compulsory and all other moves can be made
     if cMove == False:
         while i < len(locationList) and loc == False:
            if i%2 != 0:
                #checks which box user clicked on
                if mPosition[0] < (locationList[i][0] + 50) and mPosition[0] > (locationList[i][0] - 50) and mPosition[1] < (locationList[i][1] + 50) and abs(locationList[i][1] - mPosition[1]) < 50:
                    BN = locationList[i-1]
                    for d in range(len(pieceList)):
                        if locationList[i] == pieceList[d]:  
                              if locationList[i-1]%8 != 7 and locationList[i-1]%8 != 0 and (pieceList[d-1] == -1 or pieceList[d-1] == 30):
                                  if pieceList[d-1] < 12 and Turn == True:
                                    if pieceList[d-1] == -1:
                                        # if piece is a king then it calculates all the possible locations a king can move to provided no piece is present.
                                        #pieceList[d-1] < 12 means its a red piece and Turn == True means its reds turn
                                        if locationList[i-1] < 8:
                                            Location1 = locationList[i-1] + 7
                                            Location2 = locationList[i-1] + 9
                                        elif locationList[i-1] > 55:
                                            Location3 = locationList[i-1] - 7
                                            Location4 = locationList[i-1] - 9
                                        else:
                                            Location1 = locationList[i-1] + 7
                                            Location2 = locationList[i-1] + 9
                                            Location3 = locationList[i-1] - 7
                                            Location4 = locationList[i-1] - 9
                                            
                                   
                                  else:
                                    if pieceList[d-1] >= 12 and Turn == False:
                                      if pieceList[d-1] == 30:
                                        if locationList[i-1] < 8:
                                            Location1 = locationList[i-1] + 7
                                            Location2 = locationList[i-1] + 9
                                        elif locationList[i-1] > 55:
                                            Location3 = locationList[i-1] - 7
                                            Location4 = locationList[i-1] - 9
                                        else:
                                            Location1 = locationList[i-1] + 7
                                            Location2 = locationList[i-1] + 9
                                            Location3 = locationList[i-1] - 7
                                            Location4 = locationList[i-1] - 9
                                            
                                  # in this loop it will iterate for the length of locationList ( which stores box number and coordinates of each square on the board)
                                  # then if the possible move box of the piece is empty, it highlights the box, otherwise if the box is occupied by an opponents piece
                                  #it checks if the diagonal box after the opponents piece is free and highlights that (meaning a kill can be made)
                                  for m in range(len(locationList)):
                                     if pieceList[d-1] == -1 and Turn == True:
                                       if locationList[i-1] < 8:
                                         if locationList[m] == Location1: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location5 = Location1 + 7
                                                        if Location1 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location5:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                            boolK = True
                                         if locationList[m] == Location2:
                                                if locationList[m+1] not in pieceList:  
                                                  pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                                  loc = True
                                                else:
                                                    if locationList[m+1] not in pieceList[25:]: 
                                                        Location6 = Location2 + 9
                                                        if Location2 % 8 != 7: 
                                                            for l in range(len(locationList)):
                                                                if locationList[l] == Location6:
                                                                    Coords = locationList[l+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                boolK = True                
                                       elif locationList[i-1] > 55:
                                         
                                         if locationList[m] == Location3:
                                          
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location7 = Location3 - 7
                                                        if Location3 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location7:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                         if locationList[m] == Location4:
                                                if locationList[m+1] not in pieceList:  
                                                  pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                                  loc = True
                                                  boolK = True
                                                else:
                                                     if locationList[m+1] not in pieceList[:25]:
                                                        Location8 = Location4 - 9
                                                        if Location4 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location8:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                       else:
                                         if locationList[m] == Location1:
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location5 = Location1 + 7
                                                        if Location1 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location5:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                         if locationList[m] == Location2:
                                            if locationList[m+1] not in pieceList:  
                                                  pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                                  loc = True
                                                  boolK = True
                                            else:
                                              if locationList[m+1] not in pieceList[:25]:
                                                        Location6 = Location2 + 9
                                                        if Location2 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location6:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                         if locationList[m] == Location3: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location7 = Location3 - 7
                                                        if Location3 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location7:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                         if locationList[m] == Location4:
                                            if locationList[m+1] not in pieceList:  
                                                  pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                                  loc = True
                                                  boolK = True
                                            else:
                                                 if locationList[m+1] not in pieceList[:25]:
                                                        Location8 = Location4 - 9
                                                        if Location4 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location8:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True

                                     elif pieceList[d-1] == 30 and Turn == False:
                                       if locationList[i-1] < 8:
                                         if locationList[m] == Location1:
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[25:]:
                                                        Location5 = Location1 + 7
                                                        if Location1 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location5:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                                        
                                         if locationList[m] == Location2:
                                                if locationList[m+1] not in pieceList:  
                                                  pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                                  loc = True
                                                  boolK = True
                                                else:
                                                    if locationList[m+1] not in pieceList[25:]: 
                                                        Location6 = Location2 + 9
                                                        if Location2 % 8 != 7: 
                                                            for l in range(len(locationList)):
                                                                if locationList[l] == Location6:
                                                                    Coords = locationList[l+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                        boolK = True
                                       elif locationList[i-1] > 55:
                                         if locationList[m] == Location3:
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[25:]:
                                                        Location7 = Location3 - 7
                                                        if Location3 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location7:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                         if locationList[m] == Location4:
                                                if locationList[m+1] not in pieceList:  
                                                  pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                                  loc = True
                                                  boolK = True
                                                else:
                                                     if locationList[m+1] not in pieceList[25:]:
                                                        Location8 = Location4 - 9
                                                        if Location4 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location8:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                       else:
                                         if locationList[m] == Location1:
                                      
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                               
                                                if locationList[m+1] not in pieceList[25:]:
                                                        Location5 = Location1 + 7
                                                        if Location1 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location5:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                         if locationList[m] == Location2:
                                            if locationList[m+1] not in pieceList:  
                                                  pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                                  loc = True
                                                  boolK = True
                                            else:
                                              if locationList[m+1] not in pieceList[25:]:
                                                        Location6 = Location2 + 9
                                                        if Location2 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location6:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                         if locationList[m] == Location3:
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[25:]:
                                                        Location7 = Location3 - 7
                                                        if Location3 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location7:
                                                                    Coords = locationList[f+1]
                                                        if Coords != (' ', ' '):
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                         if locationList[m] == Location4:
                                            if locationList[m+1] not in pieceList:  
                                                  pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                                  loc = True
                                                  boolK = True
                                            else:
                                                 if locationList[m+1] not in pieceList[25:]:
                                                        Location8 = Location4 - 9
                                                        if Location4 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location8:
                                                                    Coords = locationList[f+1]
                                                        if Coords != (' ', ' '):
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True

                              #this code has the same functionality but now it has fewer avilable move boxes as this code works when the piece is in
                              # the far right column and can only move left
                              elif locationList[i-1] % 8 == 7 and (pieceList[d-1] == -1 or pieceList[d-1] == 30):
                                  if locationList[i-1] > 55:
                                      Location1 = locationList[i-1] - 9
                                  elif locationList[i-1] < 8:
                                      Location2 = locationList[i-1] + 9
                                  else:
                                      Location3 = locationList[i-1] + 9
                                      Location4 = locationList[i-1] - 9
                                  
                                  for m in range(len(locationList)):
                                     if pieceList[d-1] == -1 and Turn == True:
                                       if locationList[i-1] < 8:
                                         if locationList[m] == Location2: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location5 = Location2 + 9
                                                        if Location2 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location5:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                       elif locationList[i-1] > 55:
                                         if locationList[m] == Location1: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location6 = Location1 - 9
                                                        if Location1 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location6:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                         else:
                                          if locationList[m] == Location3: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location7 = Location3 + 9
                                                        if Location2 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location7:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                          elif locationList[m] == Location4: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location7 = Location4 - 9
                                                        if Location4 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location7:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                     if pieceList[d-1] == 30 and Turn == False:
                                       if locationList[i-1] < 8:
                                         if locationList[m] == Location1: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location5 = Location1 + 9
                                                        if Location1 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location5:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                       elif locationList[i-1] > 55:
                                         if locationList[m] == Location2: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location6 = Location2 - 9
                                                        if Location2 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location6:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                         else:
                                          if locationList[m] == Location3: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location7 = Location3 + 9
                                                        if Location2 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location7:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                          elif locationList[m] == Location4: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location7 = Location4 - 9
                                                        if Location4 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location7:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True



                                                   
                               #this code has the same functionality but now it has fewer avilable move boxes as this code works when the piece is in
                              # the far left column and can only move right
                              elif locationList[i-1] % 8 == 0 and (pieceList[d-1] == -1 or pieceList[d-1] == 30):
                                  if locationList[i-1] > 55:
                                      Location1 = locationList[i-1] - 7
                                  elif locationList[i-1] < 8:
                                      Location2 = locationList[i-1] + 7
                                  else:
                                      Location3 = locationList[i-1] + 7
                                      Location4 = locationList[i-1] - 7
                                  
                                  for m in range(len(locationList)):
                                     if pieceList[d-1] == -1 and Turn == True:
                                       if locationList[i-1] < 8:
                                         if locationList[m] == Location2: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location5 = Location2 + 7
                                                        if Location2 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location5:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                       elif locationList[i-1] > 55:
                                         if locationList[m] == Location1: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location6 = Location1 - 7
                                                        if Location1 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location6:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                         else:
                                          if locationList[m] == Location3: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location7 = Location3 + 7
                                                        if Location2 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location7:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                          elif locationList[m] == Location4: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location7 = Location4 - 7
                                                        if Location4 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location7:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                     if pieceList[d-1] == 30 and Turn == False:
                                       if locationList[i-1] < 8:
                                         if locationList[m] == Location1: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location5 = Location1 + 7
                                                        if Location1 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location5:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                       elif locationList[i-1] > 55:
                                         if locationList[m] == Location2: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location6 = Location2 - 7
                                                        if Location2 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location6:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                         else:
                                          if locationList[m] == Location3: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location7 = Location3 + 7
                                                        if Location2 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location7:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True
                                          elif locationList[m] == Location4: 
                                           if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                               boolK = True
                                           else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                        Location7 = Location4 - 7
                                                        if Location4 % 8 != 0:
                                                            for f in range(len(locationList)):
                                                                if locationList[f] == Location7:
                                                                    Coords = locationList[f+1]
                                                            if (Coords[0],Coords[1]) not in pieceList:
                                                                pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                            loc = True
                                                        boolK = True

                              #this code works for pieces which are not kings and performs the same functions as the code above but it does not highlight the
                              #boxes which would allow the piece to move backward since that is not allowed
                              if locationList[i-1]%8 != 7 and locationList[i-1]%8 != 0 and boolK == False:
                                  if pieceList[d-1] < 12 and Turn == True:
                                      Location1 = locationList[i-1] + 7
                                      Location2 = locationList[i-1] + 9
                                  else:
                                     if pieceList[d-1] >= 12 and Turn == False:  
                                      Location1 = locationList[i-1] - 7
                                      Location2 = locationList[i-1] - 9
                                  for m in range(len(locationList)):
                                       if locationList[m] == Location1:
                                          if pieceList[d-1] < 12 and Turn == True:
                                             if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                               loc = True
                                             else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                    Location3 = Location1 + 7
                                                    if Location1 % 8 != 0:
                                                        for f in range(len(locationList)):
                                                            if locationList[f] == Location3:
                                                                Coords = locationList[f+1]
                                                        if (Coords[0],Coords[1]) not in pieceList:
                                                            pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                        loc = True
                                          else:
                                            if pieceList[d-1] >= 12 and Turn == False:
                                             if locationList[m+1] not in pieceList:
                                               pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100)) 
                                               loc = True
                                             else:
                                              if locationList[m+1] not in pieceList[25:]:
                                                Location3 = Location1 - 7
                                                if Location3 > 0:
                                                    if Location1 % 8 != 7: 
                                                        for l in range(len(locationList)):
                                                            if locationList[l] == Location3:
                                                                Coords = locationList[l+1]
                                                        if (Coords[0],Coords[1]) not in pieceList:
                                                            pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))  
                                       if locationList[m] == Location2:                                   
                                          if pieceList[d-1] < 12 and Turn == True:
                                            
                                            if locationList[m+1] not in pieceList:  
                                             pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                            else:
                                                if locationList[m+1] not in pieceList[:25]:
                                                    Location3 = Location2 + 9
                                                    if Location2 % 8 != 7: 
                                                        for g in range(len(locationList)):
                                                            if locationList[g] == Location3:
                                                                Coords = locationList[g+1]
                                                        if (Coords[0],Coords[1]) not in pieceList:
                                                            pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                          else: 
                                            if pieceList[d-1] >= 12 and Turn == False: 
                                             if locationList[m+1] not in pieceList:   
                                              pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                             else:
                                               if locationList[m+1] not in pieceList[25:]:   
                                                Location3 = Location2 - 9
                                                if Location3 > 0:
                                                    if Location2 % 8 != 0: 
                                                        for h in range(len(locationList)):
                                                            if locationList[h] == Location3:
                                                                Coords = locationList[h+1]
                                                        if (Coords[0],Coords[1]) not in pieceList:
                                                            pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                    
                                        
                                          loc = True    
                              elif locationList[i-1]%8 == 7:
                                   if pieceList[d-1] < 12 and Turn == True:
                                      Location1 = locationList[i-1] + 7
                                   else:
                                     if pieceList[d-1] >= 12 and Turn == False:  
                                      Location1 = locationList[i-1] - 9 
                                   for m in range(len(locationList)):
                                      if locationList[m] == Location1:
                                          if pieceList[d-1] < 12 and Turn == True:
                                            if locationList[m+1] not in pieceList:
                                             pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                            else:
                                             if locationList[m+1] not in pieceList[:25]: 
                                                    Location3 = Location1 + 7
                                                    for f in range(len(locationList)):
                                                        if locationList[f] == Location3:
                                                            Coords = locationList[f+1]
                                                    if (Coords[0],Coords[1]) not in pieceList:
                                                        pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                    loc = True
                                          else:
                                           if pieceList[d-1] >= 12 and Turn == False:   
                                            if locationList[m+1] not in pieceList:
                                             pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                            else:
                                                if locationList[m+1] not in pieceList[25:]:   
                                                    Location3 = Location1 - 9
                                                    for h in range(len(locationList)):
                                                        if locationList[h] == Location3:
                                                            Coords = locationList[h+1]
                                                    if (Coords[0],Coords[1]) not in pieceList:
                                                        pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                          loc = True
                                          
                              elif locationList[i-1]%8 == 0:
                                   if pieceList[d-1] < 12 and Turn == True:
                                     Location1 = locationList[i-1] + 9
                                   else:
                                      if pieceList[d-1] >= 12 and Turn == False: 
                                       Location1 = locationList[i-1] - 7
                                   for m in range(len(locationList)):
                                       if locationList[m] == Location1: 
                                          if pieceList[d-1] < 12 and Turn == True:
                                            if locationList[m+1] not in pieceList:
                                             pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                            else:
                                                 if locationList[m+1] not in pieceList[:25]:
                                                    Location3 = Location1 + 9
                                                    for g in range(len(locationList)):
                                                        if locationList[g] == Location3:
                                                            Coords = locationList[g+1]
                                                    if (Coords[0],Coords[1]) not in pieceList:
                                                        pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                          else:
                                           if pieceList[d-1] >= 12 and Turn == False:   
                                            if locationList[m+1] not in pieceList:
                                             pygame.draw.rect(gameScreen,blue,pygame.Rect((locationList[m+1][0]-50),(locationList[m+1][1]-50),100,100))
                                            else:
                                                if locationList[m+1] not in pieceList[25:]:
                                                    Location3 = Location1 - 7
                                                    for l in range(len(locationList)):
                                                        if locationList[l] == Location3:
                                                            Coords = locationList[l+1]
                                                    if (Coords[0],Coords[1]) not in pieceList:
                                                        pygame.draw.rect(gameScreen,blue,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                                
                                          loc = True
                                                          
            i += 2
     return BN   

#this function will check to see what should be done with a box a user has clicked on
def evaluateMove(gameScreen,locationList,pieceList,variable,mPosition,BN):
    i = 1
    a=1
    Bool1 = False
    white =(255,255,255)
    black = (0,0,0)
    green = (0,0,0)
    red = (255,0,0)
    blue = (0,0,255)
    gold = (255,215,0)
    global Turn
    Coord = (' ', ' ')
    global Kbool
    while variable == False:
        # this checks that if the box chosen is blue in color then it moves the piece to the box. since this function is coming right after the highlight moves
        # function in this particular case so it uses the box number BN returned by the highlight moves function above to see which piece the user has clicked on
        #before
        if  gameScreen.get_at((mPosition[0],mPosition[1]))  == (0,0,255,255):
          while a < len(locationList) and Bool1 == False:   
            if mPosition[0] < (locationList[a][0] + 50) and mPosition[0] > (locationList[a][0] - 50) and mPosition[1] < (locationList[a][1] + 50) and abs(locationList[a][1] - mPosition[1]) < 50:
                boxNumber2 = locationList[a-1]
                if abs(BN - boxNumber2) == 7 or abs(BN - boxNumber2) == 9:
                    if Turn == True:
                        c = 1    
                        while c < len(locationList):
                            if gameScreen.get_at((locationList[c][0]+46,locationList[c][1]))  == (0,0,255,255):
                                if gameScreen.get_at((locationList[c-2][0]+46,locationList[c-2][1])) == (255,255,255,255) and locationList[c-1] % 8 != 0 :
                                   pygame.draw.rect(gameScreen,green,pygame.Rect((locationList[c][0] - 50),(locationList[c][1] - 50),100,100))
                                else:
                                   pygame.draw.rect(gameScreen,white,pygame.Rect((locationList[c][0] - 50),(locationList[c][1] - 50),100,100))
                            c += 2
                        #if Kbool equals true then it means the code is dealing with a king piece and so it also has to draw the gold circle in the red circle
                        if Kbool == True:
                            Kbool = False
                            pygame.draw.circle(gameScreen,red,(locationList[a][0],locationList[a][1]),40)
                            pygame.draw.circle(gameScreen,gold,(locationList[a][0],locationList[a][1]),20)        
                        else:
                            pygame.draw.circle(gameScreen,red,(locationList[a][0],locationList[a][1]),40)
                        for b in range(len(locationList)):
                            if locationList[b] == BN:
                                Coords = locationList[b+1]
                        pygame.draw.rect(gameScreen,white,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                        for v in range(len(pieceList)):
                            if (Coords[0],Coords[1]) == pieceList[v]:
                                pieceList[v] = (locationList[a][0],locationList[a][1])
                        if Turn == True:
                            Turn = False
                        else:
                            Turn = True
                    #for blacks turn.
                    else:
                        c = 1    
                        while c < len(locationList):
                            if gameScreen.get_at((locationList[c][0]+46,locationList[c][1]))  == (0,0,255,255):
                                if gameScreen.get_at((locationList[c-2][0]+46,locationList[c-2][1])) == (255,255,255,255) and locationList[c-1] % 8 != 0 :
                                   pygame.draw.rect(gameScreen,green,pygame.Rect((locationList[c][0] - 50),(locationList[c][1] - 50),100,100))
                                else:
                                   pygame.draw.rect(gameScreen,white,pygame.Rect((locationList[c][0] - 50),(locationList[c][1] - 50),100,100))
                            c += 2
                        if Kbool == True:
                            Kbool = False
                            pygame.draw.circle(gameScreen,green,(locationList[a][0],locationList[a][1]),40)
                            pygame.draw.circle(gameScreen,gold,(locationList[a][0],locationList[a][1]),20)
                        else:
                            pygame.draw.circle(gameScreen,green,(locationList[a][0],locationList[a][1]),40)
                        for b in range(len(locationList)):
                            if locationList[b] == BN:
                                Coords = locationList[b+1]
                        for v in range(len(pieceList)):
                            if (Coords[0],Coords[1]) == pieceList[v]:
                                pieceList[v] = (locationList[a][0],locationList[a][1])
                        pygame.draw.rect(gameScreen,white,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                        if Turn == True:
                            Turn = False
                        else:
                            Turn = True
                #here it works for boxes highlighted for when a piece can be killed which is on the right of the piece the user clicked on
                elif abs(BN - boxNumber2) == 14:
                        if Turn == True:
                            c = 1    
                            while c < len(locationList):
                                if gameScreen.get_at((locationList[c][0]+46,locationList[c][1]))  == (0,0,255,255):
                                    if gameScreen.get_at((locationList[c-2][0]+46,locationList[c-2][1])) == (255,255,255,255) and locationList[c-1] % 8 != 0 :
                                       pygame.draw.rect(gameScreen,green,pygame.Rect((locationList[c][0] - 50),(locationList[c][1] - 50),100,100))
                                    else:
                                       pygame.draw.rect(gameScreen,white,pygame.Rect((locationList[c][0] - 50),(locationList[c][1] - 50),100,100))
                                c += 2
                            if Kbool == True and (boxNumber2 < BN):
                                boxNumber3 = boxNumber2 + 7
                            else:
                                boxNumber3 = boxNumber2 - 7
                            Bool2 = False
                            n = 0
                            while n < len(locationList) and Bool2 == False:
                                for b in range(len(locationList)):
                                        if locationList[b] == BN:
                                          Coords = locationList[b+1]
                                        if boxNumber3 == locationList[b]:
                                            Coord = locationList[b+1]
                                if boxNumber2 == locationList[n]:
                                    if locationList[n+1] not in pieceList:
                                        if Kbool == True:
                                            Kbool = False
                                            print '1'
                                            pygame.draw.circle(gameScreen,red,(locationList[n+1][0],locationList[n+1][1]),40)
                                            pygame.draw.circle(gameScreen,gold,(locationList[n+1][0],locationList[n+1][1]),20)
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coord[0]-50),(Coord[1]-50),100,100))
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                        else:
                                            pygame.draw.circle(gameScreen,red,(locationList[n+1][0],locationList[n+1][1]),40)
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coord[0]-50),(Coord[1]-50),100,100))
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                        r = 1
                                        while r < len(locationList):
                                            if gameScreen.get_at((locationList[r][0]+46,locationList[r][1]))  == (0,0,255,255):
                                                if gameScreen.get_at((locationList[r-2][0]+46,locationList[r-2][1])) == (255,255,255,255) and locationList[r-1] % 8 != 0 :
                                                   pygame.draw.rect(gameScreen,green,pygame.Rect((locationList[r][0] - 50),(locationList[r][1] - 50),100,100))
                                                else:
                                                   pygame.draw.rect(gameScreen,white,pygame.Rect((locationList[r][0] - 50),(locationList[r][1] - 50),100,100))
                                            r += 2
                                        for v in range(len(pieceList)):
                                            if (Coords[0],Coords[1]) == pieceList[v]:
                                                pieceList[v] = (locationList[n+1][0],locationList[n+1][1])
                                            if (Coord[0],Coord[1]) == pieceList[v]:
                                                pieceList[v] = (-10,-10)
                                                pieceList[v-1] = -10
                                        Turn = False
                                n += 2
                        elif Turn == False:
                            c = 1    
                            while c < len(locationList):
                                if gameScreen.get_at((locationList[c][0]+46,locationList[c][1]))  == (0,0,255,255):
                                    if gameScreen.get_at((locationList[c-2][0]+46,locationList[c-2][1])) == (255,255,255,255) and locationList[c-1] % 8 != 0 :
                                       pygame.draw.rect(gameScreen,green,pygame.Rect((locationList[c][0] - 50),(locationList[c][1] - 50),100,100))
                                    else:
                                       pygame.draw.rect(gameScreen,white,pygame.Rect((locationList[c][0] - 50),(locationList[c][1] - 50),100,100))
                            
                                c += 2  
                            if Kbool == True and (boxNumber2 > BN):
                                boxNumber3 = boxNumber2 - 7
                            else:
                                boxNumber3 = boxNumber2 + 7
                            Bool2 = False
                            n = 0
                            while n < len(locationList) and Bool2 == False:
                                for b in range(len(locationList)):
                                            if locationList[b] == BN:
                                              Coords = locationList[b+1]
                                            if boxNumber3 == locationList[b]:
                                              Coord = locationList[b+1]
                                if boxNumber2 == locationList[n]:
                                    if locationList[n+1] not in pieceList:
                                        if Kbool == True:
                                            Kbool = False
                                            print '2'
                                            pygame.draw.circle(gameScreen,green,(locationList[n+1][0],locationList[n+1][1]),40)
                                            pygame.draw.circle(gameScreen,gold,(locationList[n+1][0],locationList[n+1][1]),20)
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coord[0]-50),(Coord[1]-50),100,100))
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                        else:
                                            pygame.draw.circle(gameScreen,green,(locationList[n+1][0],locationList[n+1][1]),40)
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coord[0]-50),(Coord[1]-50),100,100))
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                        r = 1
                                        while r < len(locationList):
                                            if gameScreen.get_at((locationList[r][0]+46,locationList[r][1]))  == (0,0,255,255):
                                                if gameScreen.get_at((locationList[r-2][0]+46,locationList[r-2][1])) == (255,255,255,255) and locationList[r-1] % 8 != 0 :
                                                   pygame.draw.rect(gameScreen,green,pygame.Rect((locationList[r][0] - 50),(locationList[r][1] - 50),100,100))
                                                else:
                                                   pygame.draw.rect(gameScreen,white,pygame.Rect((locationList[r][0] - 50),(locationList[r][1] - 50),100,100))
                                            r += 2
                                        
                                        for v in range(len(pieceList)):
                                            if (Coords[0],Coords[1]) == pieceList[v]:
                                                pieceList[v] = (locationList[n+1][0],locationList[n+1][1])
                                            if (Coord[0],Coord[1]) == pieceList[v]:
                                                pieceList[v] = (-10,-10)
                                                pieceList[v-1] = -10
                                        Turn = True
                                n += 2
                #here it works for boxes highlighted for when a piece can be killed which is on the right of the piece the user clicked on
                elif abs(BN - boxNumber2) == 18:
                         if Turn == True: 
                            c = 1    
                            while c < len(locationList):
                                if gameScreen.get_at((locationList[c][0]+46,locationList[c][1]))  == (0,0,255,255):
                                    if gameScreen.get_at((locationList[c-2][0]+46,locationList[c-2][1])) == (255,255,255,255) and locationList[c-1] % 8 != 0 :
                                       pygame.draw.rect(gameScreen,green,pygame.Rect((locationList[c][0] - 50),(locationList[c][1] - 50),100,100))
                                    else:
                                       pygame.draw.rect(gameScreen,white,pygame.Rect((locationList[c][0] - 50),(locationList[c][1] - 50),100,100))
                            
                                c += 2  
                            if Kbool == True and (boxNumber2 < BN):
                                boxNumber3 = boxNumber2 + 9
                            else:
                                boxNumber3 = boxNumber2 - 9
                            Bool2 = False
                            n = 0
                            while n < len(locationList) and Bool2 == False:
                                for b in range(len(locationList)):
                                            if locationList[b] == BN:
                                              Coords = locationList[b+1]
                                            if boxNumber3 == locationList[b]:
                                                Coord = locationList[b+1]
                                if boxNumber2 == locationList[n]:
                                    if locationList[n+1] not in pieceList:
                                        if Kbool == True:
                                            Kbool = False
                                            print '5'
                                            pygame.draw.circle(gameScreen,red,(locationList[n+1][0],locationList[n+1][1]),40)
                                            pygame.draw.circle(gameScreen,gold,(locationList[n+1][0],locationList[n+1][1]),20)
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coord[0]-50),(Coord[1]-50),100,100))
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                        else:
                                            pygame.draw.circle(gameScreen,red,(locationList[n+1][0],locationList[n+1][1]),40)
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coord[0]-50),(Coord[1]-50),100,100))
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                        r = 1
                                        while r < len(locationList):
                                            if gameScreen.get_at((locationList[r][0]+46,locationList[r][1]))  == (0,0,255,255):
                                                if gameScreen.get_at((locationList[r-2][0]+46,locationList[r-2][1])) == (255,255,255,255) and locationList[r-1] % 8 != 0 :
                                                   pygame.draw.rect(gameScreen,green,pygame.Rect((locationList[r][0] - 50),(locationList[r][1] - 50),100,100))
                                                else:
                                                   pygame.draw.rect(gameScreen,white,pygame.Rect((locationList[r][0] - 50),(locationList[r][1] - 50),100,100))
                                            r += 2
                                    
                                        for v in range(len(pieceList)):
                                            if (Coords[0],Coords[1]) == pieceList[v]:
                                                pieceList[v] = (locationList[n+1][0],locationList[n+1][1])
                                            if (Coord[0],Coord[1]) == pieceList[v]:
                                                pieceList[v] = (-10,-10)
                                                pieceList[v-1] = -10
                                        Turn = False
                                n += 2
                         elif Turn == False:
                            c = 1    
                            while c < len(locationList):
                                if gameScreen.get_at((locationList[c][0]+46,locationList[c][1]))  == (0,0,255,255):
                                    if gameScreen.get_at((locationList[c-2][0]+46,locationList[c-2][1])) == (255,255,255,255) and locationList[c-1] % 8 != 0 :
                                       pygame.draw.rect(gameScreen,green,pygame.Rect((locationList[c][0] - 50),(locationList[c][1] - 50),100,100))
                                    else:
                                       pygame.draw.rect(gameScreen,white,pygame.Rect((locationList[c][0] - 50),(locationList[c][1] - 50),100,100))
                                c += 2  
                            if Kbool == True and (boxNumber2 > BN):
                                boxNumber3 = boxNumber2 - 9
                            else:
                                boxNumber3 = boxNumber2 + 9
                            Bool2 = False
                            n = 0
                            while n < len(locationList) and Bool2 == False:
                                for b in range(len(locationList)):
                                            if locationList[b] == BN:
                                              Coords = locationList[b+1]
                                            if boxNumber3 == locationList[b]:
                                              Coord = locationList[b+1]    
                                if boxNumber2 == locationList[n]:
                                    if locationList[n+1] not in pieceList:
                                        if Kbool == True:
                                            Kbool = False
                                            print '6'
                                            pygame.draw.circle(gameScreen,green,(locationList[n+1][0],locationList[n+1][1]),40)
                                            pygame.draw.circle(gameScreen,gold,(locationList[n+1][0],locationList[n+1][1]),20)
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coord[0]-50),(Coord[1]-50),100,100))
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                        else:
                                            pygame.draw.circle(gameScreen,green,(locationList[n+1][0],locationList[n+1][1]),40)
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coord[0]-50),(Coord[1]-50),100,100))
                                            pygame.draw.rect(gameScreen,white,pygame.Rect((Coords[0]-50),(Coords[1]-50),100,100))
                                        r = 1
                                        while r < len(locationList):
                                            if gameScreen.get_at((locationList[r][0]+46,locationList[r][1]))  == (0,0,255,255):
                                                if gameScreen.get_at((locationList[r-2][0]+46,locationList[r-2][1])) == (255,255,255,255) and locationList[r-1] % 8 != 0 :
                                                   pygame.draw.rect(gameScreen,green,pygame.Rect((locationList[r][0] - 50),(locationList[r][1] - 50),100,100))
                                                else:
                                                   pygame.draw.rect(gameScreen,white,pygame.Rect((locationList[r][0] - 50),(locationList[r][1] - 50),100,100))
                                            r += 2
                                        
                                        for v in range(len(pieceList)):
                                            if (Coords[0],Coords[1]) == pieceList[v]:
                                                pieceList[v] = (locationList[n+1][0],locationList[n+1][1])
                                            if (Coord[0],Coord[1]) == pieceList[v]:
                                                pieceList[v] = (-10,-10)
                                                pieceList[v-1] = -10
                                        Turn = True
                                n += 2         
                Bool1=True
            a += 2
          Bool1 = False
          variable = 'M'
          return variable
        while i < len(locationList) and variable == False:
            if mPosition[0] < (locationList[i][0] + 50) and mPosition[0] > (locationList[i][0] - 50) and mPosition[1] < (locationList[i][1] + 50) and abs(locationList[i][1] - mPosition[1]) < 50:
                boxNumber2 = locationList[i-1]
                if gameScreen.get_at((locationList[i][0],locationList[i][1])) == gameScreen.get_at((locationList[i][0]+46,locationList[i][1])):
                        variable = "K"
                        return variable               
                if gameScreen.get_at((locationList[i][0],locationList[i][1])) == (255,0,0,255) and gameScreen.get_at((locationList[i][0]+46,locationList[i][1]))== (255,255,255,255):
                    if Turn == True:
                        variable = "H"
                        return variable
                    elif Turn == False:
                        variable = "N"  
                        return variable
                if gameScreen.get_at((locationList[i][0],locationList[i][1])) == (0,0,0,255) and gameScreen.get_at((locationList[i][0]+46,locationList[i][1]))== (255,255,255,255):
                    if Turn == False:
                       variable = "H"
                       return variable
                    elif Turn == True:
                       variable = "N"
                       return variable
                #if piece clicked on a is a king piece and it has not been through the highlighted moves function yet then turn the boolean Kbool true (used in code above when making
                #circles after moves) and returns a variable H which is used to call the highlighted moves function in the main code
                if gameScreen.get_at((locationList[i][0],locationList[i][1])) == (255,215,0,255) and gameScreen.get_at((locationList[i][0]+46,locationList[i][1]))== (255,255,255,255):
                       Kbool = True
                       variable = "H"
                       return variable
            i += 2
#checks to see if any piece left on the board, if no then sends back the winner based on which side has no pieces left
def winCheck(pieceList,locationList):
    Bool1 = True
    Bool2 = True
    global Turn
    counter2 = -1
    counter1 = -1
    for i in pieceList[:24]:
        if i != (-10,-10):
            if i != -10:
                Bool1 = False
    if Bool1 == False:
        for x in pieceList[24:]:
            if x != -10 and x != (-10,-10):
                Bool2 = False
    if Bool1 == True:
       return "Green Wins"
    elif Bool2 == True:
       return "Red Wins"
    c = 0
    if Turn == True:
           counter1 = winCheckHelper(pieceList,locationList)
    elif Turn == False:
           counter2 = winCheckHelper(pieceList,locationList)
    if counter1 == 0:
        return "Green Wins"
    elif counter2 == 0:
        return "Red Wins"
def winCheckHelper(pieceList,locationList):
    global Turn
    c = 0
    d = 0
    counter = 0
    if Turn == True:
        a = pieceList[:24]
    elif Turn == False:
        a = pieceList[24:]
    for Coords in a:
        c = 0
        for i in range(len(locationList)):
         if c%2 == 1:
           if Coords == locationList[i]:
            boxNumber = locationList[i-1]
         c += 1   
        if d%2 == 1:
            if Coords != (-10,-10):
                if boxNumber % 8 != 0 and boxNumber % 8 != 7:
                  if Turn == True:  
                    if (Coords[0]-100,Coords[1]+100) not in pieceList or (Coords[0]+100,Coords[1]+100) not in pieceList:
                        counter += 1
                    elif (Coords[0]-100,Coords[1]+100) not in pieceList[:24] or (Coords[0]+100,Coords[1]+100) not in pieceList[:24]:
                        if (Coords[0]-200,Coords[1]+200) not in pieceList and (Coords[0]-100,Coords[1]+100) not in pieceList[:24]:
                            counter += 1
                        elif (Coords[0]+200,Coords[1]+200) not in pieceList and (Coords[0]+100,Coords[1]+100) not in pieceList[:24]:
                            counter += 1
                  if Turn == False:  
                    if (Coords[0]-100,Coords[1]-100) not in pieceList or (Coords[0]+100,Coords[1]-100) not in pieceList:
                        counter += 1
                    elif (Coords[0]-100,Coords[1]-100) not in pieceList[24:] or (Coords[0]+100,Coords[1]-100) not in pieceList[24:]:
                        if (Coords[0]-200,Coords[1]-200) not in pieceList and (Coords[0]-100,Coords[1]-100) not in pieceList[24:]:
                            counter += 1
                        elif (Coords[0]+200,Coords[1]-200) not in pieceList and (Coords[0]+100,Coords[1]-100) not in pieceList[24:]:
                            counter += 1
                elif boxNumber % 8 == 0:
                    if Turn == True:
                        if (Coords[0]+100,Coords[1]+100) not in pieceList:
                             counter += 1
                        elif (Coords[0]+100,Coords[1]+100) not in pieceList[:24]:
                          if (Coords[0]+200,Coords[1]+200) not in pieceList and (Coords[0]+100,Coords[1]+100) not in pieceList[:24]:
                            counter += 1
                    elif Turn == False:
                        if (Coords[0]+100,Coords[1]-100) not in pieceList:
                            counter += 1
                        elif (Coords[0]+100,Coords[1]-100) not in pieceList[24:]:
                              if (Coords[0]+200,Coords[1]-200) not in pieceList and (Coords[0]+100,Coords[1]-100) not in pieceList[24:]:
                                counter += 1
                elif boxNumber % 8 == 7:
                    if Turn == True:
                       if (Coords[0]-100,Coords[1]+100) not in pieceList:
                          counter += 1
                       elif (Coords[0]-100,Coords[1]+100) not in pieceList[:24]:
                           if (Coords[0]-200,Coords[1]+200) not in pieceList and (Coords[0]-100,Coords[1]+100) not in pieceList[:24]:
                               counter += 1
                    elif Turn == False:
                        if (Coords[0]-100,Coords[1]-100) not in pieceList:
                            counter += 1
                        elif (Coords[0]-100,Coords[1]-100) not in pieceList[24:]:
                            if (Coords[0]-200,Coords[1]-200) not in pieceList and (Coords[0]-100,Coords[1]-100) not in pieceList[24:]:
                               counter += 1
        d += 1                       
    return counter
#here it checks if a red piece is in the first row then it makes it a king and changes its number in the pieceList to -1 and
#if a black piece is in the last row then it makes it a king and changes its number in pieceList to 30
def makeKingPiece(gameScreen,pieceList,locationList):
    global greenList
    global redList
    white =(255,255,255)
    black = (0,0,0)
    green = (0,0,0)
    red = (255,0,0)
    blue = (0,0,255)
    gold = (255,215,0)
    c = 0
    for i in range(len(pieceList[:24])):
      if c%2 == 1:
        if pieceList[i] in redList:
          if pieceList[i-1] != -1:
            pygame.draw.circle(gameScreen,gold,(pieceList[i][0],pieceList[i][1]),20)
            pieceList[i-1] = -1
      c += 1
    d = 0
    x = 24
    for b in range(len(pieceList[24:])):
      if d%2 == 1:
       if pieceList[x] in greenList:
         if pieceList[x-1] != 30:
            pygame.draw.circle(gameScreen,gold,(pieceList[x][0],pieceList[x][1]),20)
            pieceList[x-1] = 30
      x += 1
      d += 1
    return pieceList

#this function like the highlighted moves functions stores all the possible coordinates each piece can move to, then if the
#box is empty, it stores it in the moveList function and if it is occupied by an opponents piece then it checks the next diagonal
#box to see if its empty and if it is then that box's coordinates are stored in the moveList otherwise nothing is stored. The main
#difference between this and highlighted moves function is that this function works with coordinates but highlighted moves works with
#box numbers
def generateMoves(pieceList,tempList,Turn):
    x = 100
    y = 100
    moveList = []
    for i in range(len(pieceList)):
        tempList[i] = pieceList[i]
    if Turn == True:
        for x in range(len(tempList[:24])):
          if x%2 == 1:
           if tempList[x][0] != 50 and tempList[x][0] != 750:
               if tempList[x-1] == -1:
                   coordList = [((tempList[x][0] - 100),(tempList[x][1] + 100)),((tempList[x][0] + 100),(tempList[x][1] + 100)),((tempList[x][0] - 100),(tempList[x][1] - 100)),((tempList[x][0] + 100),(tempList[x][1] - 100))]
                   for i in range((len(coordList))):
                       if coordList[i][0] > 0 and coordList[i][0] <800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                           if coordList[i] in pieceList:
                               if coordList[i] in pieceList[24:]:
                                   if i == 0:
                                       if ((coordList[i][0] - 100),(coordList[i][1] + 100)) not in pieceList:
                                           moveList = moveList + [x-1]
                                           moveList = moveList + [((coordList[i][0] - 100),(coordList[i][1] + 100))]
                                   elif i == 1:
                                       if ((coordList[i][0] + 100),(coordList[i][1] + 100)) not in pieceList:
                                           moveList = moveList + [x-1]
                                           moveList = moveList + [((coordList[i][0] + 100),(coordList[i][1] + 100))]
                                   elif i == 2:
                                       if ((coordList[i][0] - 100),(coordList[i][1] - 100)) not in pieceList:
                                           moveList = moveList + [x-1]
                                           moveList = moveList + [((coordList[i][0] - 100),(coordList[i][1] - 100))]
                                   elif i == 3:
                                       if ((coordList[i][0] + 100),(coordList[i][1] - 100)) not in pieceList:
                                           moveList = moveList + [x-1]
                                           moveList = moveList + [((coordList[i][0] + 100),(coordList[i][1] - 100))]
                           else:
                                moveList = moveList + [x-1]
                                moveList = moveList + [coordList[i]]

               elif tempList[x-1] > 0:
                   coordList = [((tempList[x][0] - 100),(tempList[x][1] + 100)),((tempList[x][0] + 100),(tempList[x][1] + 100))]
                   for i in range((len(coordList))):
                       if coordList[i][0] > 0 and coordList[i][0] <800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                           if coordList[i] in pieceList:
                               if coordList[i] in pieceList[24:]:
                                   if i == 0:
                                   
                                       if ((coordList[i][0] - 100),(coordList[i][1] + 100)) not in pieceList:
                                         if (coordList[i][0] - 100) > 0 and (coordList[i][1] + 100) > 0:
                                           moveList = moveList + [x-1]  
                                           moveList = moveList + [((coordList[i][0] - 100),(coordList[i][1] + 100))]
                                           
                                   elif i == 1: 
                                       if ((coordList[i][0] + 100),(coordList[i][1] + 100)) not in pieceList:
                                        if (coordList[i][0] + 100) > 0 and (coordList[i][1] + 100) > 0:
                                           moveList = moveList + [x-1] 
                                           moveList = moveList + [((coordList[i][0] + 100),(coordList[i][1] + 100))]
                                           
                           else:
                                moveList = moveList + [x-1]
                                moveList = moveList + [coordList[i]]
          
           elif tempList[x][0] == 50:
            if tempList[x-1] == -1:
                coordList = [((tempList[x][0] + 100),(tempList[x][1] - 100)),((tempList[x][0] + 100),(tempList[x][1] + 100))]
                for i in range((len(coordList))):
                       if coordList[i][0] > 0 and coordList[i][0] <800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                           if coordList[i] in pieceList:
                               if coordList[i] in pieceList[24:]:
                                   if i == 0:
                                       if ((coordList[i][0] + 100),(coordList[i][1] - 100)) not in pieceList:
                                         if (coordList[i][0] + 100) > 0 and (coordList[i][1] - 100) > 0:
                                           moveList = moveList + [x-1]  
                                           moveList = moveList + [((coordList[i][0] + 100),(coordList[i][1] - 100))]
                                   elif i == 1:
                                       if ((coordList[i][0] + 100),(coordList[i][1] + 100)) not in pieceList:
                                         if (coordList[i][0] + 100) > 0 and (coordList[i][1] + 100) > 0:
                                           moveList = moveList + [x-1]  
                                           moveList = moveList + [((coordList[i][0] + 100),(coordList[i][1] + 100))]
                           else:
                               moveList = moveList + [x-1]
                               moveList = moveList + [coordList[i]]
            elif tempList[x-1] == -2:
                coordList = [((tempList[x][0] + 100),(tempList[x][1] + 100))]
                for i in range((len(coordList))):
                       if coordList[i][0] > 0 and coordList[i][0] <800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                           if coordList[i] in pieceList:
                               if coordList[i] in pieceList[24:]:
                                   if i == 0:
                                       if ((coordList[i][0] + 100),(coordList[i][1] + 100)) not in pieceList:
                                         if (coordList[i][0] + 100) > 0 and (coordList[i][1] + 100) > 0:
                                           moveList = moveList + [x-1]  
                                           moveList = moveList + [((coordList[i][0] + 100),(coordList[i][1] + 100))]
                           else:
                              moveList = moveList + [x-1] 
                              moveList = moveList + [coordList[i]]

           elif tempList[x][0] == 750:
            if tempList[x-1] == -1:
                coordList = [((tempList[x][0] - 100),(tempList[x][1] - 100)),((tempList[x][0] - 100),(tempList[x][1] + 100))]
                for i in range((len(coordList))):
                       if coordList[i][0] > 0 and coordList[i][0] <800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                           if coordList[i] in pieceList:
                               if coordList[i] in pieceList[24:]:
                                   if i == 0:
                                       if ((coordList[i][0] - 100),(coordList[i][1] - 100)) not in pieceList:
                                         if (coordList[i][0] - 100) > 0 and (coordList[i][1] - 100) > 0:
                                           moveList = moveList + [x-1]  
                                           moveList = moveList + [((coordList[i][0] - 100),(coordList[i][1] - 100))]
                                   elif i == 1:
                                       if ((coordList[i][0] - 100),(coordList[i][1] + 100)) not in pieceList:
                                         if (coordList[i][0] - 100) > 0 and (coordList[i][1] + 100) > 0:
                                           moveList = moveList + [x-1]  
                                           moveList = moveList + [((coordList[i][0] - 100),(coordList[i][1] + 100))]
                           else:
                               moveList = moveList + [x-1]
                               moveList = moveList + [coordList[i]]
            elif tempList[x-1] == -2:
                coordList = [((tempList[x][0] - 100),(tempList[x][1] + 100))]
                for i in range((len(coordList))):
                       if coordList[i][0] > 0 and coordList[i][0] <800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                           if coordList[i] in pieceList:
                               if coordList[i] in pieceList[24:]:
                                   if i == 0:
                                       if ((coordList[i][0] - 100),(coordList[i][1] + 100)) not in pieceList:
                                         if (coordList[i][0] - 100) > 0 and (coordList[i][1] + 100) > 0:
                                           moveList = moveList + [x-1]  
                                           moveList = moveList + [((coordList[i][0] - 100),(coordList[i][1] + 100))]
                           else:
                                moveList = moveList + [x-1]
                                moveList = moveList + [coordList[i]]
                                  
    #the next code is the same functionality wise as the code above but works for black piece.
    elif Turn == False:
        for x in range(len(tempList[24:])):
          if x%2 == 1:
           if tempList[x+24][0] != 50 and tempList[x+24][0] != 750:
               if tempList[(x-1)+24] == 30:
                   coordList = [((tempList[x+24][0] - 100),(tempList[x+24][1] + 100)),((tempList[x+24][0] + 100),(tempList[x+24][1] + 100)),((tempList[x+24][0] - 100),(tempList[x+24][1] - 100)),((tempList[x+24][0] + 100),(tempList[x+24][1] - 100))]
                   for i in range((len(coordList))):
                       if coordList[i][0] > 0 and coordList[i][0] <800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                           if coordList[i] in pieceList:
                               if coordList[i] in pieceList[:24]:
                                   if i == 0:
                                       if ((coordList[i][0] - 100),(coordList[i][1] + 100)) not in pieceList:
                                        if (coordList[i][0] - 100) > 0 and (coordList[i][1] + 100) > 0:
                                           moveList = moveList + [x+23] 
                                           moveList = moveList + [((coordList[i][0] - 100),(coordList[i][1] + 100))]
                                   elif i == 1:
                                       if ((coordList[i][0] + 100),(coordList[i][1] + 100)) not in pieceList:
                                         if (coordList[i][0] + 100) > 0 and (coordList[i][1] + 100) > 0:
                                           moveList = moveList + [x+23]  
                                           moveList = moveList + [((coordList[i][0] + 100),(coordList[i][1] + 100))]
                                   elif i == 2:
                                       if ((coordList[i][0] - 100),(coordList[i][1] - 100)) not in pieceList:
                                         if (coordList[i][0] - 100) > 0 and (coordList[i][1] - 100) > 0:
                                           moveList = moveList + [x+23]  
                                           moveList = moveList + [((coordList[i][0] - 100),(coordList[i][1] - 100))]
                                   elif i == 3:
                                       if ((coordList[i][0] + 100),(coordList[i][1] - 100)) not in pieceList:
                                         if (coordList[i][0] + 100) > 0 and (coordList[i][1] - 100) > 0:
                                           moveList = moveList + [x+23]  
                                           moveList = moveList + [((coordList[i][0] + 100),(coordList[i][1] - 100))]
                           else:
                                moveList = moveList + [x+23]
                                moveList = moveList + [coordList[i]]
               
               elif tempList[(x-1)+24] > 12:
                   coordList = [((tempList[x+24][0] - 100),(tempList[x+24][1] - 100)),((tempList[x+24][0] + 100),(tempList[x+24][1] - 100))]
                   for i in range((len(coordList))):
                       if coordList[i][0] > 0 and coordList[i][0] <800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                           if coordList[i] in pieceList:
                               if coordList[i] in pieceList[:24]:
                                   if i == 0:
                                       if ((coordList[i][0] - 100),(coordList[i][1] - 100)) not in pieceList:
                                         if (coordList[i][0] - 100) > 0 and (coordList[i][1] - 100) > 0:
                                           moveList = moveList + [x+23]  
                                           moveList = moveList + [((coordList[i][0] - 100),(coordList[i][1] - 100))]
                                   elif i == 1:
                                     
                                       if ((coordList[i][0] + 100),(coordList[i][1] - 100)) not in pieceList:
                                         if (coordList[i][0] + 100) > 0 and (coordList[i][1] - 100) > 0:
                                           moveList = moveList + [x+23]  
                                           moveList = moveList + [((coordList[i][0] + 100),(coordList[i][1] - 100))]
                           else:
                                moveList = moveList + [x+23]
                                moveList = moveList + [coordList[i]]
                             
           elif tempList[x+24][0] == 50:
            if tempList[(x-1)+24] == 30:
                coordList = [((tempList[x+24][0] + 100),(tempList[x+24][1] - 100)),((tempList[x+24][0] + 100),(tempList[x+24][1] + 100))]
                for i in range((len(coordList))):
                       if coordList[i][0] > 0 and coordList[i][0] <800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                           if coordList[i] in pieceList:
                               if coordList[i] in pieceList[:24]:
                                   if i == 0:
                                       if ((coordList[i][0] + 100),(coordList[i][1] - 100)) not in pieceList:
                                         if (coordList[i][0] + 100) > 0 and (coordList[i][1] - 100) > 0:
                                           moveList = moveList + [x+23]  
                                           moveList = moveList + [((coordList[i][0] + 100),(coordList[i][1] - 100))]
                                   elif i == 1:
                                       if ((coordList[i][0] + 100),(coordList[i][1] + 100)) not in pieceList:
                                         if (coordList[i][0] + 100) > 0 and (coordList[i][1] + 100) > 0:
                                           moveList = moveList + [x+23]  
                                           moveList = moveList + [((coordList[i][0] + 100),(coordList[i][1] + 100))]
                           else:
                               moveList = moveList + [x+23]
                               moveList = moveList + [coordList[i]]
            
            elif tempList[(x-1)+24] > 12:
                coordList = [((tempList[x+24][0] + 100),(tempList[x+24][1] - 100))]
                for i in range((len(coordList))):
                       if coordList[i][0] > 0 and coordList[i][0] <800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                           if coordList[i] in pieceList:
                               if coordList[i] in pieceList[:24]:
                                   if i == 0:
                                       if ((coordList[i][0] + 100),(coordList[i][1] - 100)) not in pieceList:
                                         if (coordList[i][0] + 100) > 0 and (coordList[i][1] - 100) > 0:
                                           moveList = moveList + [x+23]  
                                           moveList = moveList + [((coordList[i][0] + 100),(coordList[i][1] - 100))]
                           else:
                                moveList = moveList + [x+23]
                                moveList = moveList + [coordList[i]]

           elif tempList[x+24][0] == 750:
            if tempList[(x-1)+24] == 30:
                coordList = [((tempList[x+24][0] - 100),(tempList[x+24][1] - 100)),((tempList[x+24][0] - 100),(tempList[x+24][1] + 100))]
                for i in range((len(coordList))):
                       if coordList[i][0] > 0 and coordList[i][0] <800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                           if coordList[i] in pieceList:
                               if coordList[i] in pieceList[24:]:
                                   if i == 0:
                                       if ((coordList[i][0] - 100),(coordList[i][1] - 100)) not in pieceList:
                                         if (coordList[i][0] - 100) > 0 and (coordList[i][1] - 100) > 0:
                                           moveList = moveList + [x+23]  
                                           moveList = moveList + [((coordList[i][0] - 100),(coordList[i][1] - 100))]
                                   elif i == 1:
                                       if ((coordList[i][0] - 100),(coordList[i][1] + 100)) not in pieceList:
                                         if (coordList[i][0] - 100) > 0 and (coordList[i][1] + 100) > 0:
                                           moveList = moveList + [x+23]  
                                           moveList = moveList + [((coordList[i][0] - 100),(coordList[i][1] + 100))]
                           else:
                               moveList = moveList + [x+23]
                               moveList = moveList + [coordList[i]]
            elif tempList[(x-1)+24] > 12:
                coordList = [((tempList[x+24][0] - 100),(tempList[x+24][1] + 100))]
                for i in range((len(coordList))):
                       if coordList[i][0] > 0 and coordList[i][0] <800 and coordList[i][1] > 0 and coordList[i][1] < 800:
                           if coordList[i] in pieceList:
                               if coordList[i] in pieceList[:24]:
                                   if i == 0:
                                       if ((coordList[i][0] - 100),(coordList[i][1] + 100)) not in pieceList:
                                         if (coordList[i][0] - 100) > 0 and (coordList[i][1] + 100) > 0:
                                           moveList = moveList + [x+23]  
                                           moveList = moveList + [((coordList[i][0] - 100),(coordList[i][1] + 100))]
                       else:
                           moveList = moveList + [x+23]
    #calculates difference in red and black pieces (king included) which is used in minimax function
    bPiece = 0
    rPiece = 0
    for i in range(len(tempList)):
      if i%2 == 0:
        if (tempList[i] >= 0 and tempList[i] < 12)or tempList[i] == -1:
            bPiece += 1
        elif tempList[i] >= 12 or tempList[i] == 30:
            rPiece += 1
    difference = bPiece - rPiece
    return moveList,difference, tempList
#helper function
def removeElement(moveList):
    prev = " "
    for i in moveList:
        if i == prev:
            moveList.remove(i)
        prev = i


#this is the computers AI function and works for a depth level of 3. Uses recursion
#and generates moves for a state and then in the last depth level returns difference
#between the pieces (basis of evaluation and assigning scores)
def miniMax(moveList,depth,pieceList,difference,tempList):
    global Turn
    c = 0
    Turn1 = Turn
    if Turn1 == True:
        Turn1 = False
    elif Turn1 == False:
        Turn1 = True
    if depth == 3:
        scoreList1 = []
        tempList2 = [0]*48
        numberList = []
        bestMove=0
        index = 0
        for i in moveList:   
         if c%2 == 0:
             number = i
             numberList = numberList + [number]
         if c%2 == 1:
            tempList2 = makeMove(moveList,i,number,tempList)
            moveList2,difference1,temp = generateMoves(pieceList,tempList2,Turn1)
            score1 = miniMax(moveList2,depth-1,pieceList,difference1,tempList2)
            scoreList1 = scoreList1 + [score1]
         c += 1
        index = 1
        for i in range((len(scoreList1))):
             if (i+1) < len(scoreList1):
                 if scoreList1[i] >= scoreList1[i+1]:
                     bestMove = moveList[index]
                     number = numberList[i]
                     index += 2
        return bestMove,number
    if depth == 2:
        tempList3 = []*48
        scoreList2 = []
        if Turn1 == True:
          Turn1 = False
        elif Turn1 == False:
          Turn1 = True
        for i in moveList:
          if c%2 == 0:
             number = i  
          if c%2 == 1:
            tempList3 = makeMove(moveList,i,number,tempList)
            moveList2,difference2,temp = generateMoves(pieceList,tempList3,Turn1)
            score2 = miniMax(moveList,depth-1,pieceList,difference2,tempList3)
            scoreList2 = scoreList2 + [score2]
          c += 1
        return min(scoreList2)
    if depth == 1:
        tempList4 = []*48
        scoreList3 = []
        if Turn1 == True:
          Turn1 = False
        elif Turn1 == False:
          Turn1 = True
        for i in moveList:
          if c%2 == 0:
             number = i  
          if c%2 == 1:
            tempList4 = makeMove(moveList,i,number,tempList)
            moveList2,difference2,temp = generateMoves(pieceList,tempList4,Turn1)
            score3 = miniMax(moveList,depth-1,pieceList,difference2,tempList4)
            scoreList3 = scoreList3 + [score3]
          c += 1
        return max(scoreList3)
    if depth == 0:
        return difference
#helper for AI, makes the move in the temporary list (templist2,templist3 etc.)
def makeMove(moveList,i,coord,tempList):
    tempList2 = []
    for x in tempList:
        tempList2 = tempList2 + [x]
    for d in range(len(tempList)):
        if d == coord:
           tempList2[d+1] = i
    return tempList2

#this function is quite similar to mainFunction1 but this for the playerVsComputer option and
#the main difference is that the evaluate move and highlight moves function are only used for
#one player i.e. the user, the computer uses minimax function to decide move
def mainFunction2():
    pygame.quit()
    white =(255,255,255)
    black = (0,0,0)
    green = (0,0,0)
    red = (255,0,0)
    blue = (0,0,255)
    gold = (255,215,0)
    gameScreen = pygame.display.set_mode((800, 800))
    pygame.display.set_caption("Checkers vs Computer")
    gameEnd = False
    clock = pygame.time.Clock()
    drawBoard(gameScreen)
    pieceList = drawPieces(gameScreen)
    locationList = boxLocations(gameScreen)
    loc = False
    global Turn
    global greenList
    global redList
    Turn = True
    variable = False
    BN = -1
    global Kbool
    Kbool = False
    while gameEnd == False:
        pygame.display.flip()
        if Turn == True:
            global tempList
            tempList = [0] * 48
            moveList,difference,tempList = generateMoves(pieceList,tempList,Turn)
            bestMove, number = miniMax(moveList,3,pieceList,difference,tempList)
            #after the minimax function returns a value, this checks to see in which
            #direction the move is being made and makes the move. This is done by checking
            #difference between previous coordinates of the piece and new coordinates. if the
            #difference is e.g. -100 for x coordinate and -100 for y coordinate it means the piece
            # is one box left and one box up
            for i in range(len(pieceList)):
                if i == number:
                    coord = pieceList[i+1]
                    pieceList[i+1] = bestMove
                    if (bestMove[0] - coord[0]) == -200:
                        if (bestMove[1] - coord[1]) == 200:
                            pygame.draw.circle(gameScreen,red,(bestMove[0],bestMove[1]),40)
                            pygame.draw.rect(gameScreen,white,pygame.Rect(((bestMove[0]+100)-50),((bestMove[1]-100)-50),100,100))
                            pygame.draw.rect(gameScreen,white,pygame.Rect((coord[0]-50),(coord[1]-50),100,100))
                            for x in range((len(pieceList))):
                                if ((bestMove[0]+100),(bestMove[1]-100)) == pieceList[x]:
                                    pieceList[x] = (-10,-10)
                                    pieceList[x-1] = -10

                        elif (bestMove[1] - coord[1]) == -200:
                            pygame.draw.circle(gameScreen,red,(bestMove[0],bestMove[1]),40)
                            pygame.draw.circle(gameScreen,gold,(bestMove[0],bestMove[1]),20)
                            pygame.draw.rect(gameScreen,white,pygame.Rect(((bestMove[0]+100)-50),((bestMove[1]+100)-50),100,100))
                            pygame.draw.rect(gameScreen,white,pygame.Rect((coord[0]-50),(coord[1]-50),100,100))
                            for i in range((len(pieceList))):
                                if ((bestMove[0]+100),(bestMove[1]+100)) == pieceList[x]:
                                    pieceList[x] = (-10,-10)
                                    pieceList[x-1] = -10

                    if (bestMove[0] - coord[0]) == 200:
                        if (bestMove[1] - coord[1]) == 200:
                            pygame.draw.circle(gameScreen,red,(bestMove[0],bestMove[1]),40)
                            pygame.draw.rect(gameScreen,white,pygame.Rect(((bestMove[0]-100)-50),((bestMove[1]-100)-50),100,100))
                            pygame.draw.rect(gameScreen,white,pygame.Rect((coord[0]-50),(coord[1]-50),100,100))
                            for i in range((len(pieceList))):
                                if ((bestMove[0]-100),(bestMove[1]-100)) == pieceList[x]:
                                    pieceList[x] = (-10,-10)
                                    pieceList[x-1] = -10
                        elif (bestMove[1] - coord[1]) == -200:
                            pygame.draw.circle(gameScreen,red,(bestMove[0],bestMove[1]),40)
                            pygame.draw.circle(gameScreen,gold,(bestMove[0],bestMove[1]),20)
                            pygame.draw.rect(gameScreen,white,pygame.Rect(((bestMove[0]-100)-50),((bestMove[1]+100)-50),100,100))
                            pygame.draw.rect(gameScreen,white,pygame.Rect((coord[0]-50),(coord[1]-50),100,100))
                            for i in range((len(pieceList))):
                                if ((bestMove[0]-100),(bestMove[1]+100)) == pieceList[x]:
                                    pieceList[x] = (-10,-10)
                                    pieceList[x-1] = -10

                    if (bestMove[0] - coord[0]) == 100:
                        if (bestMove[1] - coord[1]) == 100:
                            pygame.draw.circle(gameScreen,red,(bestMove[0],bestMove[1]),40)
                            pygame.draw.rect(gameScreen,white,pygame.Rect((coord[0]-50),(coord[1]-50),100,100))
                        elif (bestMove[1] - coord[1]) == -100:
                            pygame.draw.circle(gameScreen,red,(bestMove[0],bestMove[1]),40)
                            pygame.draw.circle(gameScreen,gold,(bestMove[0],bestMove[1]),20)
                            pygame.draw.rect(gameScreen,white,pygame.Rect((coord[0]-50),(coord[1]-50),100,100))
                        

                    if (bestMove[0] - coord[0]) == -100:
                        if (bestMove[1] - coord[1]) == 100:
                            pygame.draw.circle(gameScreen,red,(bestMove[0],bestMove[1]),40)
                            pygame.draw.rect(gameScreen,white,pygame.Rect((coord[0]-50),(coord[1]-50),100,100))

                        elif (bestMove[1] - coord[1]) == -100:
                            pygame.draw.circle(gameScreen,red,(bestMove[0],bestMove[1]),40)
                            pygame.draw.circle(gameScreen,gold,(bestMove[0],bestMove[1]),20)
                            pygame.draw.rect(gameScreen,white,pygame.Rect((coord[0]-50),(coord[1]-50),100,100))
            Turn = False
            pieceList = makeKingPiece(gameScreen,pieceList,locationList)
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                    gameEnd = True
            if event.type == pygame.MOUSEBUTTONDOWN:
                mPosition = pygame.mouse.get_pos()
                winner = winCheck(pieceList,locationList)
                if winner == "Red Wins":
                    wonGameRed()
                elif winner == "Green Wins":
                    wonGameRed()
                pieceList = makeKingPiece(gameScreen,pieceList,locationList)   
                if  Turn == False:
                    i = 1
                    if variable == False:
                       variable = evaluateMove(gameScreen,locationList,pieceList,variable,mPosition,BN)
                    if variable == "H":
                        while i < len(locationList):
                            if gameScreen.get_at((locationList[i][0]+46,locationList[i][1]))  == (0,0,255,255):
                                if gameScreen.get_at((locationList[i-2][0]+46,locationList[i-2][1])) == (255,255,255,255) and locationList[i-1] % 8 != 0 :
                                   pygame.draw.rect(gameScreen,green,pygame.Rect((locationList[i][0] - 50),(locationList[i][1] - 50),100,100))
                                else:
                                   pygame.draw.rect(gameScreen,white,pygame.Rect((locationList[i][0] - 50),(locationList[i][1] - 50),100,100))
                            i += 2
                        BN = highlightMoves(gameScreen,pieceList,locationList,loc,mPosition)
                        variable = False
                    elif variable == "N" or variable == "K" or variable == "M":
                        variable = False
        up = pygame.key.get_pressed()[pygame.K_UP]
        if up == 1:
            gameEnd == True
            menufunc()
        down = pygame.key.get_pressed()[pygame.K_DOWN]
        if down == 1:
            gameEnd == True
            mainFunction2()
        clock.tick(50)          
    pygame.quit()                                           

#if this function is called, it makes a window congratulating the players and has two
#buttons i.e. main menu and restart which open the main menu or start the game itself respectively
def wonGameRed():
    pygame.init()
    red = (255,0,0)
    white =(255,255,255)
    menuScreen = pygame.display.set_mode((400,200))
    menuScreen.fill(red)
    pygame.display.set_caption("Congratulations!")
    textFont = pygame.font.SysFont('Comic Sans MS', 20)
    textFont2 = pygame.font.SysFont('Comic Sans MS', 14)
    pygame.draw.rect(menuScreen,white,pygame.Rect(75,120,100,40))
    pygame.draw.rect(menuScreen,white,pygame.Rect(245,120,100,40))
    WinScreen = textFont.render('Congratulations Red Won !', False, (0,0,0))
    restartScreen = textFont2.render('Restart', False, (0,0,0))
    menuBackScreen = textFont2.render('Main Menu', False, (0,0,0))
    menuScreen.blit(WinScreen,(90,50))
    menuScreen.blit(restartScreen,(100,130))
    menuScreen.blit(menuBackScreen,(260,130))
    pygame.display.flip()
    gameRun = False
    while gameRun == False:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                    gameRun = True
            if event.type == pygame.MOUSEBUTTONDOWN:
                mPosition = pygame.mouse.get_pos()
                if mPosition[0] >= 75 and mPosition[0] <= 175:
                    if mPosition[1] >= 120 and mPosition[1] <= 160:
                         gameRun = True
                         mainFunction1()
                if mPosition[0] >= 245 and mPosition[0] <= 345:
                    if mPosition[1] >= 120 and mPosition[1] <= 160:
                        gameRun = True
                        menufunc()
    pygame.quit()        

#if this function is called, it makes a window congratulating the players and has two
#buttons i.e. main menu and restart which open the main menu or start the game itself respectively
def wonGameBlack():
    pygame.init()
    red = (255,0,0)
    white =(255,255,255)
    menuScreen = pygame.display.set_mode((400,200))
    menuScreen.fill(white)
    pygame.display.set_caption("Congratulations!")
    textFont = pygame.font.SysFont('Comic Sans MS', 20)
    textFont2 = pygame.font.SysFont('Comic Sans MS', 14)
    pygame.draw.rect(menuScreen,red,pygame.Rect(75,120,100,40))
    pygame.draw.rect(menuScreen,red,pygame.Rect(245,120,100,40))
    WinScreen = textFont.render('Congratulations Black Won !', False, (0,0,0))
    restartScreen = textFont2.render('Restart', False, (0,0,0))
    menuBackScreen = textFont2.render('Main Menu', False, (0,0,0))
    menuScreen.blit(WinScreen,(90,50))
    menuScreen.blit(restartScreen,(100,130))
    menuScreen.blit(menuBackScreen,(260,130))
    pygame.display.flip()
    gameRun = False
    while gameRun == False:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                    gameRun = True
            if event.type == pygame.MOUSEBUTTONDOWN:
                mPosition = pygame.mouse.get_pos()
                if mPosition[0] >= 75 and mPosition[0] <= 175:
                    if mPosition[1] >= 120 and mPosition[1] <= 160:
                         gameRun = True
                         mainFunction1()
                if mPosition[0] >= 245 and mPosition[0] <= 345:
                    if mPosition[1] >= 120 and mPosition[1] <= 160:
                        gameRun = True
                        menufunc()
    pygame.quit()        

#this funciton is used to display the main menu with the buttons and text and image.
def menufunc():
    pygame.init()
    white =(255,255,255)
    black = (0,0,0)
    green = (0,255,0)
    red = (255,0,0)
    menuScreen = pygame.display.set_mode((1024,576))
    pygame.display.set_caption("Menu for checkers")
    gameRun = False
    Menu = pygame.image.load('Menu1.jpg')
    menuScreen.blit(Menu,(0,0))
    pygame.draw.rect(menuScreen,white,pygame.Rect(240,140,170,90))
    pygame.draw.rect(menuScreen,white,pygame.Rect(450,200,140,70))
    pygame.draw.rect(menuScreen,white,pygame.Rect(650,140,200,90))
    textFont = pygame.font.SysFont('Comic Sans MS', 25)
    offlineScreen = textFont.render('Play Offline', False, (0,0,0))
    computerScreen = textFont.render('Play Vs Computer', False, (0,0,0))
    playScreen = textFont.render('Start', False, (0,0,0))
    menuScreen.blit(offlineScreen,(260,170))
    menuScreen.blit(playScreen,(485,220))
    menuScreen.blit(computerScreen,(651,160))
    pygame.display.flip()
    offlineBool = False
    Functioncall = False
    while gameRun == False:
        for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                            gameRun = True
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        mPosition = pygame.mouse.get_pos()
                        if mPosition[0] > 240 and mPosition[0] < 410:
                            if mPosition[1] > 140 and mPosition[1] < 210:
                                pygame.draw.rect(menuScreen,green,pygame.Rect(240,140,170,90))
                                textFont = pygame.font.SysFont('Comic Sans MS', 25)
                                offlineScreen = textFont.render('Play Offline', False, (0,0,0))
                                menuScreen.blit(offlineScreen,(260,170))
                                pygame.display.flip()
                                offlineBool = True
                        if mPosition[0] > 450 and mPosition[0] < 590:
                            if mPosition[1] > 200 and mPosition[1] < 270:
                                if offlineBool == True:
                                    Functioncall = True
                                    gameRun = True
                                elif offlineBool == False:
                                    Functioncall = False
                                    gameRun = True
                        if mPosition[0] > 650 and mPosition[0] < 850:
                            if mPosition[1] > 140 and mPosition[1] < 210:
                                pygame.draw.rect(menuScreen,green,pygame.Rect(650,140,200,90))
                                textFont = pygame.font.SysFont('Comic Sans MS', 25)
                                computerScreen = textFont.render('Play Vs Computer', False, (0,0,0))
                                menuScreen.blit(computerScreen,(670,170))
                                pygame.display.flip()
                                offlineBool = False
                                
    pygame.quit()
    if Functioncall == True:
        mainFunction1()
    elif Functioncall == False:
        mainFunction2()

menufunc()
white =(255,255,255)
black = (0,0,0)
green = (0,255,0)
red = (255,0,0)





